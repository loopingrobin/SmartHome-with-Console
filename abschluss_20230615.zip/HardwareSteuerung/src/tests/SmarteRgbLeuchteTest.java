package tests;

import java.awt.Color;
import java.util.Scanner;

import de.loopingrobin.backend.Farbregler;
import de.loopingrobin.backend.Schalter;
import de.loopingrobin.backend.SmarteRgbLeuchte;
import de.loopingrobin.middletier.Uhrzeit;

/**
 * Testet die Klasse RGB-Leuchte.
 * 
 * @author Robin Wagner
 *
 */
public class SmarteRgbLeuchteTest {

	/** 
	 * Die ausführende main()-Methode.
	 * @param args Main-Parameter (ungenutzt)
	 */
	public static void main(String[] args) {
		Uhrzeit uhrzeit = new Uhrzeit();
		Schalter schalter = new Schalter("Tischschalter");
		Farbregler farbregler = new Farbregler("Farbregler", Color.WHITE);
		SmarteRgbLeuchte tischLeuchte = new SmarteRgbLeuchte("Tischleuchte", schalter, farbregler, uhrzeit);
		Thread tischThread = new Thread(tischLeuchte);
		
		tischThread.start();
		
		while(true) {
			Scanner scanner = new Scanner(System.in);
			scanner.nextLine();
//			schalter.schalten();
			farbregler.setFarbe(Color.BLACK);
			scanner.nextLine();
			farbregler.setFarbe(Color.WHITE);
		}
	}

}
