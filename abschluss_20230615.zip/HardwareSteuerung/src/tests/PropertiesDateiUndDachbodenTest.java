package tests;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

import de.loopingrobin.backend.Dachboden;
import de.loopingrobin.backend.VerwalterDesDachbodens;

/**
 * Erstellt die Properties-Datei und einen Dachboden und speichert beides.
 * 
 * @author Robin Wagner
 *
 */
public class PropertiesDateiUndDachbodenTest {

	/** 
	 * Die ausführende main()-Methode.
	 * @param args Main-Parameter (ungenutzt)
	 */
	public static void main(String[] args) {
		
		//Properties-Datei wird erstellt.
		Properties properties = new Properties();
		
		properties.setProperty("ordner", "dachboden");	
		properties.setProperty("objekt", "dachboden/smarte.geraete");
		
		//Properties-Datei wird gespeichert.
		try(OutputStream stream = new FileOutputStream("dachboden.properties")){
			properties.store(stream, "Speicherpfad fuer Dachboden");
			
		} catch (IOException ausnahme) {
			ausnahme.printStackTrace();
		}
		
		//Dachboden wird erstellt.
		Dachboden dachboden = new Dachboden();
		
		//Dachboden wird gespeichert.
		VerwalterDesDachbodens.inDateiSchreiben(dachboden);
		
		//Dachboden wird gelesen.
		Dachboden neuerDachboden = VerwalterDesDachbodens.ausDateiLesen();
		System.out.println(neuerDachboden);
	}

}
