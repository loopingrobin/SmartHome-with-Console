package tests;

/**
 * Testet die Farbausgabe der Konsole.
 * 
 * @author Robin Wagner
 *
 */
public class FarbenTest {

	/** 
	 * Die ausführende main()-Methode.
	 * @param args Main-Parameter (ungenutzt)
	 */
	public static void main(String[] args) {
		String teString = "\u001B[32mText\u001B[0mText";
		
		System.out.println(teString);
	}

}
