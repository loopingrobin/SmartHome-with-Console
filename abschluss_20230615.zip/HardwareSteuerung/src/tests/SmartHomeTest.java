package tests;

import java.awt.Color;
import java.time.LocalTime;
import java.util.Map;

import de.loopingrobin.backend.Ausfuehrungszeit;
import de.loopingrobin.backend.SmarteLeuchte;
import de.loopingrobin.backend.SmarteRgbLeuchte;
import de.loopingrobin.backend.SmarterRaum;
import de.loopingrobin.backend.SmartesGeraet;
import de.loopingrobin.middletier.SmartHome;

/**
 * Testet die Klasse SmartHome.
 * 
 * @author Robin Wagner
 *
 */
public class SmartHomeTest {

	/** 
	 * Die ausführende main()-Methode.
	 * @param args Main-Parameter (ungenutzt)
	 */
	public static void main(String[] args) {

		SmartHome jarvis = new SmartHome();
		
		//Räume hinzufügen.
		SmarterRaum kueche = new SmarterRaum("Küche");
		SmarterRaum wohnzimmer = new SmarterRaum("Wohnzimmer");
		
		jarvis.addRaum(kueche);
		jarvis.addRaum(wohnzimmer);
		
		//Smarte Geräte hinzufügen.
		jarvis.addSmartesGeraet("Smarte Leuchte", "Deckenlampe", kueche);
		jarvis.addSmartesGeraet("Smarte RGB-Leuchte", "Sofalampe", wohnzimmer);
		jarvis.addSmartesGeraet("Smarte Heizung", "Heizung West", wohnzimmer);
		jarvis.addSmartesGeraet("Smartes Fenster", "Fenster West", wohnzimmer);
		
		//Smarte Geräte einstellen.
		SmartesGeraet erstesGeraet = jarvis.getSmarteGeraete().get(0);
		SmarteLeuchte leuchte = (SmarteLeuchte) erstesGeraet;
		leuchte.addAusfuehrungszeit(new Ausfuehrungszeit(LocalTime.of(3, 0), LocalTime.of(6, 0)));
		erstesGeraet.setRaum(kueche);
		
		SmartesGeraet zweitesGeraet = jarvis.getSmarteGeraete().get(1);
		SmarteRgbLeuchte rgbLeuchte = (SmarteRgbLeuchte) zweitesGeraet;
		rgbLeuchte.addAusfuehrungszeit(new Ausfuehrungszeit(LocalTime.of(9, 0), LocalTime.of(12, 0)));
		zweitesGeraet.setRaum(wohnzimmer);

		
//		//Neue Gerätetypen hinzufügen.
//		jarvis.getDachboden().getGeraeteTypen().add("Smarte Heizung");
//		jarvis.getDachboden().getGeraeteTypen().add("Smartes Fenster");
//		
//		//Gerätetypen auflisten.
//		for (Map.Entry<Integer, String> geraeteTyp : jarvis.getGeraeteTypen().entrySet()) {
//
//			System.out.println(geraeteTyp.getValue());
//		}
		
//		//Einzelnes smartes Gerät hinzufügen.
//		SmarterRaum klo = new SmarterRaum("Klo");
//		jarvis.addSmartesGeraet("Smarte Leuchte", "kloLeuchte", klo);
//		SmartesGeraet drittesGeraet =  jarvis.getSmarteGeraete().get(1);
//		
//		
//		System.out.println(jarvis.getDachboden().getSmarteLeuchten() + "\n");
//		
//		//Einzelnes smartes Gerät auswählen.
//		System.out.println(drittesGeraet);
//		
//		//Ausgewähltes smartes Gerät entfernen.		
//		jarvis.deleteSmartesGeraet(drittesGeraet, klo);
//		System.out.println("\n" + jarvis.getDachboden().getSmarteLeuchten());
		
		Map<Integer, SmarterRaum> raeume = jarvis.getSmarteRaeume();
		SmarterRaum raum = raeume.getOrDefault(11, null);
		
		Map<Integer, SmartesGeraet> geraete = raum.getSmarteGeraete();
		SmarteRgbLeuchte leuchteRgb = (SmarteRgbLeuchte) geraete.getOrDefault(10, null);
		
		System.out.println("Color.RED.equals leuchteRgb.getFarbe() : " + (leuchteRgb.getFarbe().equals(Color.RED)));
		System.out.println();
		
//		for (Map.Entry<Integer, SmartesGeraet> geraet : geraete.entrySet()) {
//			System.out.println(geraet.getKey() + ": " + geraet.getValue());
//		}
		
		jarvis.speichern();
		
	}

}
