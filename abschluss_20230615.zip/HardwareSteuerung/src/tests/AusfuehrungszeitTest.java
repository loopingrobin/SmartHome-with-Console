package tests;

import java.time.LocalTime;
import java.util.Map;

import de.loopingrobin.backend.Ausfuehrungszeit;
import de.loopingrobin.backend.Schalter;
import de.loopingrobin.backend.SmarteLeuchte;
import de.loopingrobin.middletier.Uhrzeit;

/**
 * Testet die Klassen SmarteLeuchte, Ausfuehrungszeit und Uhrzeit.
 * 
 * @author Robin Wagner
 *
 */
public class AusfuehrungszeitTest {

	/** 
	 * Die ausführende main()-Methode.
	 * @param args Main-Parameter (ungenutzt)
	 */
	public static void main(String[] args) {
		Schalter schalter = new Schalter("Lichtschalter");
		Uhrzeit uhr = new Uhrzeit();
		SmarteLeuchte licht = new SmarteLeuchte("Licht", schalter, uhr);
		
		Thread lichtThread = new Thread(licht);
		Thread uhrtThread = new Thread(uhr);
		
		lichtThread.start();
		uhrtThread.start();
		
		licht.addAusfuehrungszeit(new Ausfuehrungszeit(LocalTime.of(3, 0), LocalTime.of(6, 0)));
		licht.addAusfuehrungszeit(new Ausfuehrungszeit(LocalTime.of(9, 0), LocalTime.of(12, 0)));
		licht.addAusfuehrungszeit(new Ausfuehrungszeit(LocalTime.of(15, 0), LocalTime.of(18, 0)));
		licht.addAusfuehrungszeit(new Ausfuehrungszeit(LocalTime.of(21, 0), LocalTime.of(23, 0)));
		for (Map.Entry<Integer, Ausfuehrungszeit> zeit : licht.getAusfuehrungszeiten().entrySet()) {
			System.out.println(zeit.getValue());
		}
		
		while(lichtThread.isAlive() || uhrtThread.isAlive()) {
			if (uhr.getUhrzeit() == LocalTime.of(10, 0)) {
				schalter.schalten();
				
				try {
					Thread.sleep(1100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}
