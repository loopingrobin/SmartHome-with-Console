package tests;

import java.util.Scanner;

import de.loopingrobin.backend.Schalter;
import de.loopingrobin.backend.SmarteLeuchte;
import de.loopingrobin.middletier.Uhrzeit;

/**
 * Testet die Klasse Smarte Leuchte.
 * 
 * @author Robin Wagner
 *
 */
public class SmarteLeuchteTestMitSchalter {

	/** 
	 * Die ausführende main()-Methode.
	 * @param args Main-Parameter (ungenutzt)
	 */
	public static void main(String[] args) {
		
		Scanner hoerer = new Scanner(System.in);
		Uhrzeit uhrzeit = new Uhrzeit();
		
		Schalter kuechenSchalter = new Schalter("Küchenschalter");
		Schalter kellerSchalter = new Schalter("Kellerschalter");
		Schalter flurSchalter = new Schalter("Flurschalter");
		Schalter schlafzimmerSchalter = new Schalter("Schlafzimmerschalter");
		
		SmarteLeuchte kuechenLeuchte = new SmarteLeuchte( "Küche", kuechenSchalter, uhrzeit);
		SmarteLeuchte kellerLeuchte = new SmarteLeuchte("Keller", kellerSchalter, uhrzeit);
		SmarteLeuchte flurLeuchte = new SmarteLeuchte("Flur", flurSchalter, uhrzeit);
		SmarteLeuchte schlafzimmerLeuchte = new SmarteLeuchte("Schlafzimmer", schlafzimmerSchalter, uhrzeit);
		
		Thread kueche = new Thread(kuechenLeuchte);
		Thread keller = new Thread(kellerLeuchte);
		Thread flur = new Thread(flurLeuchte);
		Thread schlafzimmer = new Thread(schlafzimmerLeuchte);
		
		kueche.start();
		keller.start();
		flur.start();
		schlafzimmer.start();
		
		while (kueche.isAlive() || keller.isAlive() || flur.isAlive() || schlafzimmer.isAlive()) {
			System.out.println("\n---- Welchen Schalter willst du drücken ----");
			System.out.println("1: " + kuechenSchalter.getName());
			System.out.println("2: " + kellerSchalter.getName());
			System.out.println("3: " + flurSchalter.getName());
			System.out.println("4: " + schlafzimmerSchalter.getName());
			System.out.println("---------------------------------------------\n");
			
			int schalterGedrueckt = hoerer.nextInt();
			
			if (schalterGedrueckt == 1) {
				kuechenSchalter.schalten();
			} else if (schalterGedrueckt == 2) {
				kellerSchalter.schalten();
			} else if (schalterGedrueckt == 3) {
				flurSchalter.schalten();
			} else if (schalterGedrueckt == 4) {
				schlafzimmerSchalter.schalten();
			}

			try {
				Thread.sleep(2);
			} catch (InterruptedException ausnahme) {
				ausnahme.printStackTrace();
			}
		}
	}

}
