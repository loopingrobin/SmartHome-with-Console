package tests;

import de.loopingrobin.backend.Luftqualitaetsregler;
import de.loopingrobin.backend.Schalter;
import de.loopingrobin.backend.SmarteHeizung;
import de.loopingrobin.backend.SmarterRaum;
import de.loopingrobin.backend.SmartesFenster;
import de.loopingrobin.backend.Temperaturregler;
import de.loopingrobin.middletier.Uhrzeit;

/**
 * Testet die Klasse SmarteHeizung und SmartesFenster.
 * 
 * @author Robin Wagner
 *
 */
public class SmarteHeizungTest {

	/** 
	 * Die ausführende main()-Methode.
	 * @param args Main-Parameter (ungenutzt)
	 */
	public static void main(String[] args) {
		SmarterRaum wohnzimmer = new SmarterRaum("Wohnzimmer");
		Uhrzeit uhrzeit = new Uhrzeit();
		
		Schalter schalterHeizung = new Schalter("SchalterWest");
		Temperaturregler reglerHeizung = new Temperaturregler("ReglerWest", 20, 17);
		SmarteHeizung heizkoerper = new SmarteHeizung("HeizkörperWest", schalterHeizung, reglerHeizung, uhrzeit);
		
		Schalter schalterFenster = new Schalter("FenterSchalter");
		Luftqualitaetsregler reglerFenster = new Luftqualitaetsregler("ReglerFenster", 500, 1000);
		SmartesFenster fenster = new SmartesFenster("FensterZumHof", schalterFenster, reglerFenster, uhrzeit);
		
		heizkoerper.setRaum(wohnzimmer);
		fenster.setRaum(wohnzimmer);
		
		Thread uhrzeitThread = new Thread(uhrzeit);
		uhrzeitThread.start();
		Thread heizkoerperThread = new Thread(heizkoerper);
		heizkoerperThread.start();
		Thread fensterThread = new Thread(fenster);
		fensterThread.start();
		
		for (int i = 0; i < 6; i++) {
			System.out.println("Im Wohnzimmer sind es " + wohnzimmer.getRaumTemperatur() + "°C und " + wohnzimmer.getKohlenstoffDioxidGehaltInDerLuft() + " ppm"); 
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
//		schalterHeizung.schalten();
		
		reglerHeizung.setEinstiegstemperatur(22);
		reglerHeizung.setZieltemperatur(25);
		
		while (true) {
			System.out.println("Im Wohnzimmer sind es " + wohnzimmer.getRaumTemperatur() + "°C und " + wohnzimmer.getKohlenstoffDioxidGehaltInDerLuft() + " ppm"); 
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
