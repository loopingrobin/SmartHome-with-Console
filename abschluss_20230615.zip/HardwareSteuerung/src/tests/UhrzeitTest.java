package tests;

import java.time.LocalTime;

import de.loopingrobin.middletier.Uhrzeit;

/**
 * Testet die Klasse Uhrzeit.
 * 
 * @author Robin Wagner
 *
 */
public class UhrzeitTest {

	/** 
	 * Die ausführende main()-Methode.
	 * @param args Main-Parameter (ungenutzt)
	 */
	public static void main(String[] args) {
		Uhrzeit uhr = new Uhrzeit();
		Thread uhrThread = new Thread(uhr);
		uhrThread.start();
		
		LocalTime uhrzeitVorher = LocalTime.of(0, 0);
		
		while(uhrThread.isAlive()) {
			if (uhrzeitVorher != uhr.getUhrzeit()) {
				uhrzeitVorher = uhr.getUhrzeit();
				System.out.println(uhr.getUhrzeit());
			}
		}
	}

}
